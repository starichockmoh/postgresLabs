export interface IVehicle {
  car_number: string;
  model: string;
  lifting_capacity: number;
  date_of_manufacture: string;
  group_id: number;
}
