export interface IPickupPoint {
  town: string;
  street: string;
  house_number: string;
  corps: string;
}
