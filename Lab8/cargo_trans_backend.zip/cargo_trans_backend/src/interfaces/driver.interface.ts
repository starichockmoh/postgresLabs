export interface IDriver {
  last_name: string;
  first_name: string;
  patronymic: string;
  experience: number;
}
