export interface ICargo {
  name: string;
  weight: number;
  request_id: number;
  client_id: number;
  type_id: number;
}
