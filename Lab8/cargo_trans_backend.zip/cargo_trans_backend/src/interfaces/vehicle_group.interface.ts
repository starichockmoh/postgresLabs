export interface IVehicleGroup {
  group_name: string;
}
