export interface IRequest {
  name: string;
  description: string;
  cost: number;
  date_created: string;
  driver_id: number;
  vehicle_id: number;
  status_id: number;
}
