export interface IClient {
  last_name: string;
  first_name: string;
  patronymic: string;
  username: string;
  password: string;
}
