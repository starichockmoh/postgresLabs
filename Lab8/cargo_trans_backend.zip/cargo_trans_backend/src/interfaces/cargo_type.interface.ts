export interface ICargoType {
  name: string;
}
