import { ReactNode } from 'react';

export interface IOption {
  value: Number;
  label: ReactNode;
}
