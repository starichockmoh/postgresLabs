import PageTable from 'pages/PageTable/PageTable';

export default PageTable;
