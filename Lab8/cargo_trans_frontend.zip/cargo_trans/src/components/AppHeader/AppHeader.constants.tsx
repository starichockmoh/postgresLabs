export const MENU_CONSTANTS = [
  {
    label: 'Грузы',
    value: 'cargoes',
    isUser: true,
  },
  {
    label: 'Заявки',
    value: 'requests',
    isUser: true,
  },
  {
    label: 'Водители',
    value: 'drivers',
  },
  {
    label: 'Транспортные средства',
    value: 'vehicles',
  },
  {
    label: 'Типы грузов',
    value: 'cargo_types',
  },
  {
    label: 'Типы ТС',
    value: 'vehicle_types',
  },
  {
    label: 'Пункты доставки',
    value: 'pick_up_points',
  },
  {
    label: 'Клиенты',
    value: 'clients',
  },
];
