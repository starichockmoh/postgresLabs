import { AsyncSelect } from './AsyncSelect';

export default AsyncSelect;
