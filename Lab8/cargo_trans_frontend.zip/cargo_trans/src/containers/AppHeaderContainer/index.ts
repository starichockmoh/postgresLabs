import AppHeaderContainer from './AppHeaderContainer';

export default AppHeaderContainer;
