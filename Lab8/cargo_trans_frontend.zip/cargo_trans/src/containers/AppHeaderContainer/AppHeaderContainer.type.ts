export interface AppHeaderContainerProps {
  isSuperUser: boolean;
  setSuperUser: (isSuper: boolean) => void;
}
