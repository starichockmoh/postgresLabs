# Старт проекта

### `yarn install`

### `yarn start`

